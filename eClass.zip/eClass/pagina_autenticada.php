<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: usuario.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Boas vindas</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css2.css">
    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="page-header">
        <h1>Olá, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Bem vindo ao site e aproveite!.</h1>
    </div>
    <p>
        <a href="reset-password.php" class="btn btn-warning">Redefinir senha</a>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </p>

    <div id="video">
        <iframe width="480" height="365"

        src="https://www.youtube.com/embed/19vH1tnBdlU?playlist=tgbNymZ7vqY&loop=1">
            
        </iframe>

    </div>
</body>
</html>