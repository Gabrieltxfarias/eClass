<?php

$server = "localhost";
$user = "root";
$pass = "";
$dbname = "crud";

$conn = mysqli_connect($server,$user,$pass,$dbname);

?>