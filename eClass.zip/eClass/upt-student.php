<?php
  include_once "config.php";
  $id = $_POST['id'];
  $name = utf8_decode($_POST['name']);  
  $subject = utf8_decode($_POST['subject']);
  $query_update = "UPDATE alunos
  SET nome = '$name',materia='$subject'
  WHERE id = '$id'";
  mysqli_query($link,$query_update);
  header("Location: enrolled-students.php");

?>