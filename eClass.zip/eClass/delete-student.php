<?php
  include_once "config.php";
  $id = $_GET['id'];
  $delete_query = "DELETE FROM alunos WHERE id='$id'";
  mysqli_query($link,$delete_query);
  header("Location: enrolled-students.php");
?>