<?php

include_once("config.php");

$name = utf8_decode($_POST['name']);
$subject = utf8_decode($_POST['subject']);

$result = "INSERT INTO alunos (nome,materia) VALUES('$name','$subject')";
mysqli_query($link,$result);

if(mysqli_insert_id($link)){
  header("Location: enrolled-students.php");
}else{

}

?>